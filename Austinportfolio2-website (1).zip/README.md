# Austin Mbuyi Portfolio

Personal portfolio website for Austin Mbuyi.

## Files
- `index.html` — website structure/content
- `style.css` — responsive design
- `script.js` — mobile navigation

## Publish with GitHub Pages
1. Create/open the repository `Austinportfolio2`.
2. Upload `index.html`, `style.css`, and `script.js` to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Your site should be available at:
   `https://austin5kk.github.io/Austinportfolio2/`
